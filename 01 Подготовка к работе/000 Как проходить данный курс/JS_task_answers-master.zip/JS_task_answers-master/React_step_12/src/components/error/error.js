import React from 'react';

const Error = () => {
    return <div className="error">Error</div>
}

export default Error;