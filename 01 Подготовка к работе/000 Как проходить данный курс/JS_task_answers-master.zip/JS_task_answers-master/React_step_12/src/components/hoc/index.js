import WithRestoService from './with-resto-service';

export default WithRestoService;