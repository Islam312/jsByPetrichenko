import MainPage from './main-page';
import CartPage from './cart-page';

export {
    MainPage,
    CartPage
};