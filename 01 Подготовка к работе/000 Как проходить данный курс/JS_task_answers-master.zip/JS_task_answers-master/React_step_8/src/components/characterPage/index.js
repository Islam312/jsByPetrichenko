import CharacterPage from './characterPage';
export default CharacterPage;